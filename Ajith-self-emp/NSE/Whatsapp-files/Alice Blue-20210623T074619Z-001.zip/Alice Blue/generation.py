from alice_blue import *
import csv
import datetime
import time
import document_details

username = document_details.username
password = document_details.password
twoFA = document_details.twoFA
api_secret = document_details.api_secret
app_id = document_details.app_id

# access_token = AliceBlue.login_and_get_access_token(username= username, password= password, twoFA= twoFA,  api_secret= api_secret, app_id = app_id)
# print(access_token)

# with open('access_token.txt','w') as wr1:
# 	wr=csv.writer(wr1)
# 	wr.writerow([access_token])
# access_token=open('access_token.txt','r').read().strip()
access_token = "zK6NWJydVT7qTTnl-e2hIQoSSpW7i29BPoiQBwOwR6A.Ky12Pw9Nfbn6qUvUXNN4JClIIvLZyHAmFFk0Km4HPIk"
alice=AliceBlue(username= username ,password= password, access_token=access_token, master_contracts_to_download=['NSE', 'BSE', 'NFO', 'MCX'])

socket_opened = False
def event_handler_quote_update(message):
    print(f"quote update {message}")

def open_callback():
    global socket_opened
    socket_opened = True

alice.start_websocket(subscribe_callback=event_handler_quote_update,
                      socket_open_callback=open_callback,
                      run_in_background=True)
while(socket_opened==False):
    pass
alice.subscribe(alice.get_instrument_by_symbol('NSE', 'TATASTEEL'), LiveFeedType.MARKET_DATA)
time.sleep(10)